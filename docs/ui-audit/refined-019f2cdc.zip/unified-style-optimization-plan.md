# OCR / 文档 RAG 产品 — Lumia Graphite Workbench 改造计划

## 当前状态
- 项目根目录: C:\Users\35160\Documents\中医国学RAG
- 前端文件: 2 个
- 后端文件: 27 个
- 有 Vite: False
- 有 FastAPI: False

## 统一改造计划
1. 外壳重构：AppShell + CommandRail + WorkbenchMain + InspectorPanel
2. 页面分区规范化：WorkbenchSection / MetricLedger / EvidenceLedger / CommandConsole
3. 色彩主题：#F5F4F2 #EBE9E6 #2C2B28 #DDDCD9
4. 动效：Motion 开屏 + Lenis 平滑滚动 + 鼠标热区微动效
5. 技术栈：Radix UI + TanStack Query + Tauri (Rust)
生成时间：2026-07-22 02:47:48