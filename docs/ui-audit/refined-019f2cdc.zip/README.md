# 会话 019f2cdc
产品类型：OCR / 文档 RAG 产品
精确项目根目录：C:\Users\35160\Documents\中医国学RAG

## 扫描摘要
- 前端文件数：2
- 后端文件数：27
- 有 package.json：False
- 有 Vite 配置：False
- 有 FastAPI：False
- 前端文件（前10）：
  - docs\file-cleaner\index.html
  - outputs\chatbox.html

## 建议统一风格改造
- 外观改为 Lumia Graphite Workbench 风格（暖石墨 + 纸面灰 + 低饱和金属色）
- 页面结构改为 命令轨 + 工作面 + Inspector
- 控件改为 WorkbenchSection / MetricLedger / EvidenceLedger / CommandConsole
- 动效参考 Motion + Lenis
生成时间：2026-07-22 02:47:48